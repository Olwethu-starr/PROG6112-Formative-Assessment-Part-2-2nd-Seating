/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package coffeehutreport;


/**
 *
 * @author Student
 */
public class CoffeeHutReport {
    public static void main(String[] args) {
        // 2 Dimensional arrays        
        String[] cities = {
        "Cape Town"
        "Port Elizabeth"
        "Pretoria"
        };    

        String[] beverage = {
        "Coffee"
        "Tea"
        "Boba Tea"
        };
        
        //2 Dimensional arrays
        int[][] sales = {
        {500, 300, 125}
        {450, 250, 100}
        {480, 175, 120}
        };            
                
        int[] grandtotal = 0
      
        //Display Heading
        System.out.println("===============================")
        System.out.println("NUMBER 1 COFFEE HUT APPLICATION")
        System.out.println("===============================")  
        
        //Display table heading and calculate cities totals
        System.out.Printf("-20%s, "city");
        
        for (int i = 0; i < bevarage.length; i++) {
        System.out.printf("%-12s", beverages[i])
                }
        System.out.printf("%-12s%n, Total")
        
        System.out.println("==============================");
        for(int i = 0; i < sales.length; i++) {
        
        cityotal = 0
                
        System.out.printf("5-20S", cities[i]); {
        
        for (int j = 0; j < sales[i].length j++)
        System.out.printf("%-12d", sales[i][j]);
        citytotal += sales[i][j];
        
} 
        System.out.printf("%-12d%n", sales);
        grandtotal += citytotal;
        
        System.out.println("==============================");
        
        //Calculate Totals for each beverage
        System.out.printf("%-20s", "Total Sales");
        
        for (int j = 0; j < beverages.length; j++) {
            beverageTotal += sales[i][j];
        
        System.out.printf("-12%s", beverageTotal);
        
        System.out.printf("%-12d%n", grandTotal);
        
        System.out.println("===============================");
        System.out.println("Total Sales for all cities" + grandtotal);

    }
}
